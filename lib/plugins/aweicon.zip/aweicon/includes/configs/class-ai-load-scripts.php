<?php

/**
 * AIScripts
 *
 * @class 		AC_Scripts
 * @package		AweContent
 * @author 		HaLe
 * @version     1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AIScripts {
	public function __construct() {
		// Load script admin.
		add_action( 'admin_enqueue_scripts', array( $this, 'adminScripts' ) );
	}
	public function adminScripts(){

		wp_register_script( 'list.js', plugin_dir_url( AWE_ICON_FILE ) . '/assets/backend/vendor/list.min.js', array(), '1.2.0', true );
		wp_register_script( 'ai-vendor', plugin_dir_url( AWE_ICON_FILE ) . '/assets/backend/vendor/vendor.min.js', array( 'jquery' ), '06092016', true );
		wp_register_script( 'ac-icon-manager', plugin_dir_url( AWE_ICON_FILE ) . '/assets/backend/js/icon-manager.js', array( 'backbone','ai-vendor', 'list.js' ), '04092016', true );
		wp_enqueue_style( 'ai-admin-css', plugin_dir_url( AWE_ICON_FILE ) . '/assets/backend/css/admin.css' );

	}
}
new AIScripts();
