<?php 
/**
* Class final load module handle aweicon plugin
*
* @version 1.0
* @author HaLe
* 
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( !class_exists( 'AweIcon' ) ) {

	final class AweIcon{
		
		private static $getInstance = null;

		/**
		 * Auto-load in-accessible properties on demand.
		 *
		 * @param mixed $key
		 * @return mixed
		 */
		public function __get( $key ){
			if ( in_array( $key, array( 'icon' ) ) ) {
				return $this->$key();
			}
		}

		function __construct(){
			$this->loadModule();
			add_action( 'init', array( &$this, 'init' ), 0 );
		}

		/**
		 * init Init plugin
		 * 
		 * @return void
		 */
		public function init() {

		}


		/**
		 * loadModule.
		 * Load module for aweicon.
		 *
		 * @return void
		 */
		public function loadModule(){
			require_once 'configs/class-ai-load-scripts.php';
			require_once AWE_ICON_PLUGIN_DIR . '/includes/classes/icon-manager/class-ac-icon-manager.php';
			
			if ( is_user_logged_in() ) {
				require_once 'classes/admin/class-ai-admin-menu.php';
			}

			do_action( 'ai_load_module' );
		}

		/**
		 * Get the instane of aweicon.
		 *
		 * @return object
		 */
		public static function getInstance(){
			if( ! self::$getInstance instanceof self ) {
				self::$getInstance = new self;
			}

			return self::$getInstance;
		}

		public function icon(){
			return AweIconManager::get_instance();
		}

	}
}

/**
 * Return Instance plugin
 */
function AWEI() {
	return AweIcon::getInstance();
}
AWEI();

