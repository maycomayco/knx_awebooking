<?php
/**
 * Icon manager main template.
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="icon-manager-wrap" class="wrap theme-install-php icon-manager-wrap">
	<h2>
		<?php esc_html_e( 'Font Icon Manager', 'awecontent' ); ?>
		<a href="#upload-icon" class="add-new-h2"><?php esc_html_e( 'Upload Icon Pack', 'awecontent' ); ?></a>
	</h2>

	<?php $this->output_upload_form(); ?>
	<?php $this->show_messages(); ?>

	<div class="wp-filter">
		<div class="filter-count">
			<span class="count theme-count"><?php echo esc_html( count( $icons ) ); ?></span>
		</div>

		<ul class="filter-links">
			<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=ac-icon-manager&tab=uploaded' ) ); ?>" class="<?php echo 'uploaded' === $current_tab ? 'current' : ''; ?>"><?php esc_html_e( 'Uploaded', 'awecontent' ); ?></a> </li>
			<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=ac-icon-manager&tab=system' ) ); ?>" class="<?php echo 'system' === $current_tab ? 'current' : ''; ?>"><?php esc_html_e( 'System Icons', 'awecontent' ); ?></a> </li>
		</ul>

		<div class="search-form search-icons">
			<input type="search" class="wp-filter-search search" placeholder="<?php esc_html_e( 'Search Icon Pack', 'awecontent' ); ?>">
		</div>
	</div>

	<div class="metabox-holder ac-icon-manager list clear">
		<?php foreach ( $icons as $icon ) :
			$this->add_icons_box( $icon );
		endforeach; ?>
	</div>

	<ul class="pagination ac-pagination clear"></ul>
	<p class="no-themes no-icons hide-if-no-js"><?php esc_html_e( 'No icon pack found.', 'awecontent' ); ?></p>
</div>
