<?php
/**
 * Admin Icon Manager.
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AweIconManager' ) ) :

	/**
	 * The AweIconManager Class.
	 */
	class AweIconManager {
		/**
		 * Icons list.
		 *
		 * @var array
		 */
		protected $icons = array();

		/**
		 * Store uploaded icons slug.
		 *
		 * @var string
		 */
		protected $uploaded_icons = array();

		/**
		 * The option key to get uploaded icons.
		 *
		 * @var string
		 */
		protected $option_key;

		/**
		 * Upload tmp icons path.
		 *
		 * @var string
		 */
		protected $upload_tmp_path;

		/**
		 * Icons path.
		 *
		 * @var string
		 */
		protected $upload_icons_path;

		/**
		 * Icons URL.
		 *
		 * @var string
		 */
		protected $upload_icons_url;

		/**
		 * Singleton reference to singleton instance.
		 *
		 * @var static
		 */
		private static $instance;

		/**
		 * Alias of get_instance method.
		 *
		 * @return static
		 */
		public static function init() {
			return static::get_instance();
		}

		/**
		 * Gets the instance via lazy initialization.
		 *
		 * @return static
		 */
		public static function get_instance() {
			if ( null === static::$instance ) {
				static::$instance = new static;
			}

			return static::$instance;
		}

		/**
		 * Private constructor of class.
		 * Pls use: AweIconManager::instance().
		 */
		private function __construct() {
			require_once dirname( __FILE__ ) . '/class-ac-icon-model.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-abstract.php';

			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-icomoon.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-pixeden.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-fontello.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-ionicons.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-octicons.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-foundation.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-fontawesome.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-paymentfont.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-elusive.php';
			require_once dirname( __FILE__ ) . '/parser/class-ac-icon-parser-themify.php';

			$upload = wp_upload_dir();
			$this->upload_tmp_path   = trailingslashit( apply_filters( 'ac_upload_icons_tmp_path', $upload['basedir'] . '/ac-tmp' ) );
			$this->upload_icons_path = trailingslashit( apply_filters( 'ac_upload_icons_path', $upload['basedir'] . '/ac-icons' ) );
			$this->upload_icons_url  = trailingslashit( apply_filters( 'ac_upload_icons_url', $upload['baseurl'] . '/ac-icons' ) );

			// Setting uploaded icons.
			$this->option_key = apply_filters( 'ac_uploaded_icons_option_key', '_ac_uploaded_icons' );
			$this->uploaded_icons = (array) get_option( $this->option_key, array() );

			// Sync uploaded icons.
			$this->sync_uploaded_icons();

			/**
			 * You can be add custom icons here.
			 *
			 * @param AweIconManager $this AweIconManager instance.
			 */
			do_action( 'ac_icon_register', $this );
		}

		/**
		 * Register a new icon.
		 *
		 * @param  AC_Icon_Model|string $name AC_Icon_Model instance, or unique icon name.
		 * @param  array                $args Icon arguments.
		 * @return AC_Icon_Model
		 */
		public function register_icon( $name, $args = array() ) {
			if ( $name instanceof AC_Icon_Model ) {
				$icon = $name;
			} else {
				$icon = new AC_Icon_Model( $name, $args );
			}

			return $this->icons[ $icon->name ] = $icon;
		}

		/**
		 * Remove a icon.
		 *
		 * @param  string $name Icon name.
		 * @return void
		 */
		public function unregister_icon( $name ) {
			unset( $this->icons[ $name ] );
		}

		/**
		 * Retrieve a icon.
		 *
		 * @param  string $name Name of the icon.
		 * @return AC_Icon_Model|null The AC_Icon_Model instance, if set.
		 */
		public function get_icon( $name ) {
			if ( isset( $this->icons[ $name ] ) ) {
				return $this->icons[ $name ];
			}
		}

		/**
		 * If isset a icon.
		 *
		 * @param  string $name Name of the icon.
		 * @return boolean
		 */
		public function has_icon( $name ) {
			return isset( $this->icons[ $name ] );
		}

		/**
		 * Retrieve a collection of icons.
		 *
		 * @return array
		 */
		public function get_icons() {
			return $this->icons;
		}

		/**
		 * Retrieve raw icons.
		 *
		 * @return array
		 */
		public function get_raw_icons() {
			return array_map( function ( $icon ) {

				return $icon->icons;

			}, $this->icons );
		}

		/**
		 * Get the tmp-path.
		 *
		 * @return string
		 */
		public function get_upload_tmp_path() {
			return $this->upload_tmp_path;
		}

		/**
		 * Get the icons path.
		 *
		 * @return string
		 */
		public function get_upload_icons_path() {
			return $this->upload_icons_path;
		}

		/**
		 * Get icons URL.
		 *
		 * @return string
		 */
		public function get_upload_icons_url() {
			return $this->upload_icons_url;
		}

		/**
		 * Guest parser provider by directory.
		 *
		 * @param  string $directory Icon font directory.
		 * @return AC_Admin_Icon_Parse_Abstract|false
		 */
		public function parse( $directory ) {
			$providers = apply_filters( 'ac_icon_parser_providers', array(
				'AC_Icon_Parser_Pixeden',
				'AC_Icon_Parser_Icomoon',
				'AC_Icon_Parser_Fontello',
				'AC_Icon_Parser_Ionicons',
				'AC_Icon_Parser_Octicons',
				'AC_Icon_Parser_Foundation',
				'AC_Icon_Parser_FontAwesome',
				'AC_Icon_Parser_PaymentFont',
				'AC_Icon_Parser_Elusive',
				'AC_Icon_Parser_Themify',
			) );

			foreach ( $providers as $provider ) {
				if ( call_user_func( array( $provider, 'check' ), $directory ) ) {
					return new $provider( $directory );
				}
			}

			return false;
		}

		/**
		 * Install icon form zip file format.
		 *
		 * @param  string $zipfile Zipfile path.
		 * @return AC_Icon_Model|WP_Error
		 */
		public function install_from_zip( $zipfile ) {
			list( $directory, $working_directory ) = $this->unzip_file( $zipfile, $this->upload_tmp_path );

			if ( is_wp_error( $directory ) ) {
				return $directory;
			}

			return $this->install( $directory, $working_directory, true );
		}

		/**
		 * Install icon form a directory.
		 *
		 * @param  string  $directory         Source directory.
		 * @param  string  $working_directory The directory we working on it.
		 * @param  boolean $delete_after      Delete directory or working_directory after.
		 * @return AC_Icon_Model|WP_Error
		 */
		public function install( $directory, $working_directory = null, $delete_after = false ) {
			$parser = $this->parse( $directory );

			if ( false === $parser ) {
				if ( $delete_after ) {
					$this->delete_directory( $directory, $working_directory );
				}

				return new WP_Error( 'incompatible_folder_parser', esc_html__( 'Incompatible folder to parse', 'awecontent' ) );
			}

			if ( $parser->is_error() ) {
				if ( $delete_after ) {
					$this->delete_directory( $directory, $working_directory );
				}

				// TODO: Check empty icons.

				return $parser->get_error();
			}

			// TODO: We need check version of icon.
			if ( $this->is_upload_icon( $parser->icon_name() ) ) {
				if ( $delete_after ) {
					$this->delete_directory( $directory, $working_directory );
				}

				return new WP_Error( 'error', sprintf( esc_html__( 'The icon pack with name "%s" has been exists.', 'awecontent' ),  $parser->icon_name() ) );
			}

			$icon_name = $parser->icon_name();
			$destination = $this->upload_icons_path . trailingslashit( $icon_name );

			// Ensure destination exits.
			if ( ! is_dir( $destination ) ) {
				mkdir( $destination, 0777, true );
			}

			if ( ! is_dir( $destination . 'fonts/' ) ) {
				mkdir( $destination . 'fonts/', 0777, true );
			}

			// Move fonts to new folder.
			foreach ( $parser->fonts_path() as $path ) {
				if ( $parser->lock ) {
					copy( $path, $destination . 'fonts/' . basename( $path ) );
				} else {
					copy( $path, $destination . 'fonts/' . $icon_name . '.' . pathinfo( $path, PATHINFO_EXTENSION ) );
				}
			}

			// Write style.css, icons.json.
			file_put_contents( $destination . 'style.css', $this->rewrite_css( $parser ) );
			file_put_contents( $destination . 'icons.json', json_encode( $parser->icons() ) );
			file_put_contents( $destination . 'index.php', "<?php\n// Silence is golden." );

			// Add icon-slug to wp-options table.
			$this->add_upload_icon( $icon_name );

			if ( $delete_after ) {
				$this->delete_directory( $directory, $working_directory );
			}

			return $this->get_icon( $icon_name );
		}

		/**
		 * Get all uploaded icons slug.
		 *
		 * @return array
		 */
		public function get_uploaded_icons() {
			return $this->uploaded_icons;
		}

		/**
		 * Add a upload icon.
		 *
		 * @param  string $slug Slug upload icon.
		 * @return boolean
		 */
		public function add_upload_icon( $slug ) {
			if ( ! $this->is_upload_icon( $slug, false ) ) {
				return false;
			}

			$new_icons = $this->get_uploaded_icons();

			if ( ! in_array( $slug, $new_icons ) ) {
				$new_icons[] = $slug;
				sort( $new_icons );

				// Update new upload icons.
				update_option( $this->option_key, $new_icons );

				$this->uploaded_icons = $new_icons;
				$this->sync_uploaded_icons();

				return true;
			}

			return false;
		}

		/**
		 * Delete a upload icon.
		 *
		 * @param  string $slug Slug upload icon.
		 * @return boolean
		 */
		public function delete_upload_icon( $slug ) {
			if ( ! $this->is_upload_icon( $slug ) ) {
				return false;
			}

			$update_icons = $this->get_uploaded_icons();
			$key = array_search( $slug, $update_icons );

			if ( false !== $key ) {
				unset( $update_icons[ $key ] );
				update_option( $this->option_key, $update_icons );

				$this->unregister_icon( $slug );
				$this->uploaded_icons = $update_icons;

				$this->delete_directory( $this->upload_icons_path . $slug );

				return true;
			}

			return false;
		}

		/**
		 * Check if given a valid upload icon by icon slug.
		 *
		 * @param  string  $slug        Icon slug name.
		 * @param  boolean $force_check Check icon-slug exists in uploaded_icons?.
		 * @return boolean
		 */
		public function is_upload_icon( $slug, $force_check = true ) {
			if ( $force_check && ! in_array( $slug, $this->get_uploaded_icons() ) ) {
				return false;
			}

			// Get directory path.
			$directory = trailingslashit( $this->upload_icons_path . $slug );

			if ( ! is_dir( $directory ) ) {
				return false;
			}

			if ( ! file_exists( $directory . 'style.css' ) || ! file_exists( $directory . 'icons.json' ) ) {
				return false;
			}

			return true;
		}

		/**
		 * Sync uploaded icons with registered icons.
		 */
		public function sync_uploaded_icons() {
			foreach ( $this->get_uploaded_icons() as $slug ) {
				if ( ! $this->is_upload_icon( $slug ) ) {
					continue;
				}

				$this->unregister_icon( $slug );

				$args = array(
					'label'      => ucwords( str_replace( '-', ' ', $slug ) ),
					'style'      => $this->upload_icons_url . $slug . '/style.css',
					'json_icons' => $this->upload_icons_path . $slug . '/icons.json',
				);

				$this->register_icon( new AC_Icon_Model( $slug, $args, AC_Icon_Model::UPLOAD ) );
			}
		}

		/**
		 * Utils: Delete a directory.
		 *
		 * @param  string $directory         Source directory.
		 * @param  string $working_directory The directory we working on it.
		 */
		public function delete_directory( $directory, $working_directory = null ) {
			WP_Filesystem();
			global $wp_filesystem;

			if ( $wp_filesystem->is_dir( $directory ) ) {
				$wp_filesystem->rmdir( $directory, true );
			}

			if ( $wp_filesystem->is_dir( $working_directory ) ) {
				$wp_filesystem->rmdir( $working_directory, true );
			}
		}

		/**
		 * Utils: Unzip a file and return correctly folder.
		 *
		 * @param  string $zipfile        Zip file path.
		 * @param  string $base_directory The base folder where extract to.
		 * @return array
		 */
		public function unzip_file( $zipfile, $base_directory ) {
			WP_Filesystem();
			global $wp_filesystem;

			// We need a working directory first.
			$working_directory = trailingslashit( $base_directory . '/' . pathinfo( $zipfile, PATHINFO_FILENAME ) );
			$unzip_result = unzip_file( $zipfile, $working_directory );

			if ( is_wp_error( $unzip_result ) ) {
				return array( $unzip_result, null ); // WP_Error instance.
			}

			// Find the right folder.
			$source_files = array_keys( $wp_filesystem->dirlist( $working_directory ) );

			if ( count( $source_files ) === 0 ) {
				return array( new WP_Error( 'incompatible_archive_empty', esc_html__( 'Incompatible archive empty', 'awecontent' ) ), null );
			} elseif ( 1 == count( $source_files ) && $wp_filesystem->is_dir( $working_directory . $source_files[0] ) ) {
				$directory = $working_directory . trailingslashit( $source_files[0] );
			} else {
				$directory = $working_directory;
			}

			return array( $directory, $working_directory );
		}

		/**
		 * Utils: Rewrite and minify CSS.
		 *
		 * @param  string $parser The parser instance.
		 * @return string
		 */
		public function rewrite_css( $parser ) {
			$css = @file_get_contents( $parser->style_path() );

			// Don't process if we have a empty CSS.
			if ( ! is_string( $css ) || empty( $css ) ) {
				return '';
			}

			// Change fonts path.
			$css = preg_replace( '/url\(([\'"])?/', 'url($1::', $css );
			$css = preg_replace( '/\.\.?\/|fonts?\//', '::', $css );
			$css = preg_replace( '/[\:\:]{2,}+/', 'fonts/', $css );

			if ( ! $parser->lock ) {
				// Minify CSS, See: https://www.w3.org/TR/CSS2/grammar.html#scanner
				$css = preg_replace( '#\/\*[^*]*\*+([^/*][^*]*\*+)*\/#', '', $css ); // Remove comments.
				$css = preg_replace( '/\s+/', ' ', $css ); // Remove whitespace.

				// Change fonts name.
				foreach ( $parser->fonts_path() as $path ) {
					$newname = $parser->icon_name() . '.' . pathinfo( $path, PATHINFO_EXTENSION );
					$css = str_replace( basename( $path ), $newname, $css );
				}

				// Never use prefix .icon for icon name.
				$css = str_replace( 'icon-', $parser->icon_name() . '-', $css );
				$css = str_replace( array( '.icon {', 'i {' ), '[class^="' . $parser->icon_name() . '-"], [class*=" ' . $parser->icon_name() . '-"] {', $css );
			}

			/**
			 * Hook ac_rewrite_icon_{provider-parser-name}_css.
			 *
			 * @param string $css Parser CSS.
			 */
			$css = apply_filters( 'ac_rewrite_icon_' . $parser->icon_name() . '_css', $css );

			/**
			 * Hook ac_rewrite_icon_css.
			 *
			 * @param string $css Parser CSS.
			 */
			$css = apply_filters( 'ac_rewrite_icon_css', $css );

			// Return parser CSS with blank line at end.
			return trim( $css ) . "\n";
		}
	}
endif;

/**
 * Single the song.
 * TODO: Improve the flow of load files.
 */
AweIconManager::init();
