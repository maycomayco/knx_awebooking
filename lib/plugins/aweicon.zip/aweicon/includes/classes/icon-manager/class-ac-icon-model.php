<?php
/**
 * Icon Model.
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Model' ) ) :

	/**
	 * The AC_Icon_Model Class.
	 */
	class AC_Icon_Model {
		/**
		 * Icon type, UPLOAD or SYSTEM.
		 */
		const UPLOAD = 'UPLOAD';
		const SYSTEM = 'SYSTEM';

		/**
		 * Icon type.
		 *
		 * @var string
		 */
		protected $type;

		/**
		 * Icon name.
		 *
		 * @var string
		 */
		public $name;

		/**
		 * Icon display name.
		 *
		 * @var string
		 */
		public $label;

		/**
		 * Icon style link.
		 *
		 * @var string
		 */
		public $style;

		/**
		 * Icons json file.
		 *
		 * @var array
		 */
		public $json_icons;

		/**
		 * Icons list.
		 *
		 * @var array
		 */
		public $icons = array();

		/**
		 * Constructor of class.
		 *
		 * @param string $name Icon unique name.
		 * @param array  $args Icon arguments.
		 * @param string $type //.
		 */
		public function __construct( $name, $args, $type = 'SYSTEM' ) {
			$keys = array_keys( get_object_vars( $this ) );
			foreach ( $keys as $key ) {
				if ( isset( $args[ $key ] ) ) {
					$this->$key = $args[ $key ];
				}
			}

			// Icon unique name.
			$this->name = sanitize_title( $name );

			// Parser raw icons.
			if ( $this->json_icons && file_exists( $this->json_icons ) ) {
				$this->icons = $this->parse_json_icons( $this->json_icons );
			} else {
				$this->icons = $this->parse_icons( (array) $this->icons );
			}

			/**
			 * The filter ac_icon_{icon-name}_icons
			 *
			 * @param array $icons array of icons list.
			 * @var array
			 */
			$this->icons = apply_filters( 'ac_icon_' . $this->name . '_icons', $this->icons );

			/**
			 * Setting icon type.
			 *
			 * The icon type must be "UPLOAD" or "SYSTEM".
			 *
			 * @var string
			 */
			$this->type = static::UPLOAD === $type ? static::UPLOAD : static::SYSTEM;
		}

		/**
		 * If icon type is UPLOAD.
		 *
		 * @return boolean
		 */
		public function is_upload_icon() {
			return static::UPLOAD === $this->type;
		}

		/**
		 * If icon type is SYSTEM.
		 *
		 * @return boolean
		 */
		public function is_system_icon() {
			return static::SYSTEM === $this->type;
		}

		/**
		 * Export icons to JSON format.
		 *
		 * @return string
		 */
		public function to_json() {
			return json_encode( array(
				'name'  => $this->name,
				'label' => $this->label,
				'style' => $this->style,
				'icons' => $this->icons,
			) );
		}

		/**
		 * Parser raw icons.
		 *
		 * @param  array $raw_icons Raw icons.
		 * @return array
		 */
		protected function parse_icons( array $raw_icons ) {
			$icons = array();

			foreach ( $raw_icons as $icon ) {
				if ( ! is_array( $icon ) || ( ! isset( $icon['name'] ) && ! isset( $icon['classes'] ) ) ) {
					continue;
				}

				$icons[] = $icon;
			}

			return $icons;
		}

		/**
		 * Parser JSON icons.
		 *
		 * @param  strign $json_path JSON icon path.
		 * @return array
		 */
		protected function parse_json_icons( $json_path ) {
			$json = @json_decode( file_get_contents( $json_path ), true );

			if ( empty( $json ) ) {
				return array();
			}

			return $this->parse_icons( (array) $json );
		}
	}
endif;
