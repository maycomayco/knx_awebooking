<?php
/**
 * Elusive Icon Parser Provider.
 *
 * @link http://elusiveicons.com/
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_Elusive' ) ) :

	/**
	 * The AC_Icon_Parser_Elusive Class.
	 */
	class AC_Icon_Parser_Elusive extends AC_Icon_Parser_FontAwesome {
		/**
		 * Where is provider is "LOCK" status
		 *
		 * We will tell with everybody is no parse CSS, no rename, etc...
		 *
		 * @var string
		 */
		public $lock = true;

		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'scss/_icons.scss';

		/**
		 * The style file name.
		 *
		 * @var string
		 */
		protected $style_name = 'css/elusive-icons.min.css';

		/**
		 * List of files, folders match folder structure.
		 *
		 * @var array
		 */
		protected static $directory_structure = array( 'fonts/', 'scss/', 'css/elusive-icons.css' );

		/**
		 * Src icon prefix.
		 *
		 * @var string
		 */
		protected $src_icon_prefix = '.#{$el-css-prefix}';

		/**
		 * Icon prefix.
		 *
		 * @var string
		 */
		protected $icon_prefix = 'el el-';

		/**
		 * Parse font icon name.
		 */
		protected function parse_icon_name() {
			return 'elusiveicons';
		}
	}
endif;
