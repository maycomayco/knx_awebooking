<?php
/**
 * Pixeden (Free) Icon Parser Provider.
 *
 * @link http://www.pixeden.com/icon-fonts
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_Pixeden' ) ) :

	/**
	 * The AC_Icon_Parser_Pixeden Class.
	 */
	class AC_Icon_Parser_Pixeden extends AC_Icon_Parser_Icomoon {
		/**
		 * Where is provider is "LOCK" status
		 *
		 * We will tell with everybody is no parse CSS, no rename, etc...
		 *
		 * @var string
		 */
		public $lock = true;

		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'icomoon/selection.json';

		/**
		 * Exclude patterns when parser.
		 *
		 * @var array
		 */
		protected $parse_ignore = array( '*/SVG/*', '*/docs/*', '*/assets/*' );

		/**
		 * List of files, folders match folder structure.
		 *
		 * @var array
		 */
		protected static $directory_structure = array( 'icomoon/', 'SVG/', 'reference.html', 'documentation.html' );

		/**
		 * Doing parser directory.
		 */
		protected function do_parse_directory() {
			if ( ! $this->parse_path ) {
				return;
			}

			// We need icon_name first.
			$this->icon_name = $this->parse_icon_name();
			$styled_path = $this->directory . $this->icon_name . '/css/' . $this->icon_name . '.css';

			if ( file_exists( $styled_path ) ) {
				$this->style_path = $styled_path;
				$this->style_name = $this->icon_name . '/css/' . $this->icon_name . '.css';
			}
		}

		/**
		 * Parse font icon name.
		 */
		protected function parse_icon_name() {
			if ( $this->icon_name ) {
				return $this->icon_name;
			}

			return parent::parse_icon_name();
		}
	}
endif;
