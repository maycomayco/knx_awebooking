<?php
/**
 * Icon Parser Abstract.
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_Abstract' ) ) :

	/**
	 * The AC_Icon_Parser_Abstract Class.
	 */
	abstract class AC_Icon_Parser_Abstract {
		/**
		 * Where is provider is "LOCK" status
		 *
		 * We will tell with everybody is no parse CSS, no rename, etc...
		 *
		 * @var string
		 */
		public $lock = false;

		/**
		 * List of files, folders match folder structure.
		 *
		 * Folder must be end with "/", ex: array( 'fonts/', 'style.css' )
		 *
		 * @var array
		 */
		protected static $directory_structure = array();

		/**
		 * Font icon root directory.
		 *
		 * @var string
		 */
		protected $directory;

		/**
		 * Font icon name.
		 *
		 * @var array
		 */
		protected $icon_name;

		/**
		 * Store icons list.
		 *
		 * @var array
		 */
		protected $icons = array();

		/**
		 * The parse file path.
		 *
		 * @var string
		 */
		protected $parse_path;

		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'icons.json';

		/**
		 * The style file path.
		 *
		 * @var string
		 */
		protected $style_path;

		/**
		 * The style file name.
		 *
		 * @var string
		 */
		protected $style_name = 'style.css';

		/**
		 * Collection of fonts path.
		 *
		 * @var string
		 */
		protected $fonts_path = array();

		/**
		 * Exclude patterns when parser.
		 *
		 * @var array
		 */
		protected $parse_ignore = array( '*/demo-files/*', '*/src/*', '*/svg/*', '*/svgs/*', '*/SVG/*', '*/SVGS/*' );

		/**
		 * Font icon files extensions.
		 *
		 * @var array
		 */
		protected $font_extensions = array( 'svg', 'otf', 'eot', 'ttf', 'woff', 'woff2' );

		/**
		 * Allowed file extensions in parser.
		 *
		 * @var array
		 */
		protected $allowed_extensions = array( 'json', 'css', 'scss', 'less', 'svg', 'otf', 'eot', 'ttf', 'woff', 'woff2' );

		/**
		 * WP_Error instance.
		 *
		 * @var null|WP_Error
		 */
		protected $error;

		/**
		 * Constructor of class.
		 *
		 * @param string $directory Font icon directory.
		 */
		public function __construct( $directory ) {
			$this->directory = trailingslashit( wp_normalize_path( $directory ) );

			// First, we parse directory.
			$this->parse_directory();

			switch ( true ) {
				case ( ! file_exists( $this->parse_path ) || ! file_exists( $this->style_path ) ) :
					$this->error = new WP_Error( 'invalid_directory_structure', esc_html__( 'Invalid directory structure', 'awecontent' ) );
					break;

				case ( filesize( $this->parse_path ) > 2097152 ) : // 2097152 = 2MB.
					$this->error = new WP_Error( 'parse_file_too_large', esc_html__( 'The parse file too large, maximum is less than 2MB', 'awecontent' ) );
					break;

				default:
					$this->icon_name = $this->parse_icon_name();
					$this->parse_icons();
					break;
			}
		}

		/**
		 * Check folder structure match with this provider.
		 *
		 * @param  string $directory Font icon directory.
		 * @return boolean
		 */
		public static function check( $directory ) {
			$directory = wp_normalize_path( $directory );
			$check = false;

			foreach ( static::$directory_structure as $name ) {
				if ( substr( $name, -1 ) == '/' ) {
					$check = is_dir( $directory . '/' . $name );
				} else {
					$check = is_file( $directory . '/' . $name );
				}

				// If we see any "false" result, breadk loop and return it.
				if ( false === $check ) {
					break;
				}
			}

			return $check;
		}

		/**
		 * Get icon name.
		 *
		 * @return array
		 */
		public function icon_name() {
			return $this->icon_name;
		}

		/**
		 * Get parsed icons.
		 *
		 * @return AC_Admin_Icon
		 */
		public function icons() {
			return $this->icons;
		}

		/**
		 * Get parse file path.
		 *
		 * @return array
		 */
		public function parse_path() {
			return $this->parse_path;
		}

		/**
		 * Get style path.
		 *
		 * @return array
		 */
		public function style_path() {
			return $this->style_path;
		}

		/**
		 * Get collection of fonts path.
		 *
		 * @return array
		 */
		public function fonts_path() {
			return $this->fonts_path;
		}

		/**
		 * Get directory.
		 *
		 * @return string
		 */
		public function get_directory() {
			return $this->directory;
		}

		/**
		 * Check is parser error.
		 *
		 * @return boolean
		 */
		public function is_error() {
			if ( is_wp_error( $this->error ) ) {
				return true;
			}

			if ( empty( $this->icon_name ) ) {
				return true;
			}

			return false;
		}

		/**
		 * Get error.
		 *
		 * @return WP_Error|null
		 */
		public function get_error() {
			return $this->error;
		}

		/**
		 * Parse font icon name.
		 */
		abstract protected function parse_icon_name();

		/**
		 * Parse icons.
		 */
		abstract protected function parse_icons();

		/**
		 * Parse directory files.
		 */
		protected function parse_directory() {
			if ( ! is_dir( $this->directory ) ) {
				return;
			}

			$pattern = implode( '|', $this->parse_ignore );
			$scandir = $this->scandir( $this->directory );

			foreach ( $scandir as $path => $fileinfo ) {
				if ( $fileinfo->isDir() || $this->str_match( $pattern, $path ) ) {
					continue;
				}

				if ( $fileinfo->isFile() && ! in_array( $fileinfo->getExtension(), $this->allowed_extensions ) ) {
					continue;
				}

				// Build font paths.
				foreach ( $this->font_extensions  as $key ) {
					if ( $key === $fileinfo->getExtension() ) {
						$this->fonts_path[ $key ] = $path;
					}
				}

				if ( $fileinfo->getBasename() === basename( $this->parse_name ) ) {
					$this->parse_path = $path;
				}

				if ( $fileinfo->getBasename() === basename( $this->style_name ) ) {
					$this->style_path = $path;
				}
			}

			$this->do_parse_directory();
		}

		/**
		 * Doing parser directory.
		 */
		protected function do_parse_directory() {}

		/**
		 * Get parsed file content.
		 *
		 * If see a json file, decode json and return it.
		 *
		 * @return array
		 */
		protected function get_parse_content() {
			static $content;

			if ( ! $content ) {
				$content = @file_get_contents( $this->parse_path );

				if ( 'json' === pathinfo( $this->parse_path, PATHINFO_EXTENSION ) ) {
					$content = json_decode( $content, true );
				}
			}

			return $content;
		}

		/**
		 * Add new icon.
		 *
		 * @param array  $name  Icon preview name.
		 * @param string $class Icon class name.
		 */
		final protected function add_icon( $name, $class ) {
			$name = str_replace( '-', ' ', $name );
			$name = ucfirst( $name );

			$this->icons[] = array(
				'name' => $name,
				'classes' => $class,
			);
		}

		/**
		 * Scan recursive directory.
		 *
		 * @param  string $directory The directory path.
		 * @return array
		 */
		protected function scandir( $directory ) {
			$iterator = new RecursiveDirectoryIterator( $directory, RecursiveDirectoryIterator::SKIP_DOTS );
			return new RecursiveIteratorIterator( $iterator, RecursiveIteratorIterator::SELF_FIRST );
		}

		/**
		 * Determine if a given string matches a given pattern.
		 *
		 * @param  string $pattern Match mattern.
		 * @param  string $value   String value.
		 * @return bool
		 */
		protected function str_match( $pattern, $value ) {
			if ( $pattern == $value ) {
				return true;
			}

			$pattern = preg_quote( $pattern, '#' );

			// Allow mutil pattern and use dot pattern like: src/*.
			$pattern = str_replace( '\|', '|', $pattern );
			$pattern = str_replace( '\*', '.*', $pattern ) . '\z';

			return (bool) preg_match( '#' . $pattern . '#', $value );
		}
	}
endif;
