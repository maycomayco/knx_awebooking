<?php
/**
 * FontAwesome Icon Parser Provider.
 *
 * @link http://fontawesome.io/
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_FontAwesome' ) ) :

	/**
	 * The AC_Icon_Parser_FontAwesome Class.
	 */
	class AC_Icon_Parser_FontAwesome extends AC_Icon_Parser_Abstract {
		/**
		 * Where is provider is "LOCK" status
		 *
		 * We will tell with everybody is no parse CSS, no rename, etc...
		 *
		 * @var string
		 */
		public $lock = true;

		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'scss/_icons.scss';

		/**
		 * The style file name.
		 *
		 * @var string
		 */
		protected $style_name = 'css/font-awesome.min.css';

		/**
		 * List of files, folders match folder structure.
		 *
		 * @var array
		 */
		protected static $directory_structure = array( 'fonts/', 'scss/', 'css/font-awesome.css' );

		/**
		 * Src icon prefix.
		 *
		 * @var string
		 */
		protected $src_icon_prefix = '.#{$fa-css-prefix}';

		/**
		 * Icon prefix.
		 *
		 * @var string
		 */
		protected $icon_prefix = 'fa fa-';

		/**
		 * Parse font icon name.
		 */
		protected function parse_icon_name() {
			return 'font-awesome';
		}

		/**
		 * Parse icons.
		 */
		protected function parse_icons() {
			$handle = @fopen( $this->parse_path, 'r' );

			while ( ! feof( $handle ) ) {
				$line = trim( fgets( $handle, 4096 ) );

				if ( false === strpos( $line, $this->src_icon_prefix ) ) {
					continue;
				}

				if ( preg_match( '/^' . preg_quote( $this->src_icon_prefix, '/' ) . '-([a-z0-9-]+)\:before/', $line, $matches ) ) {
					$this->add_icon( $matches[1], $this->icon_prefix . $matches[1] );
				}
			}
		}
	}
endif;
