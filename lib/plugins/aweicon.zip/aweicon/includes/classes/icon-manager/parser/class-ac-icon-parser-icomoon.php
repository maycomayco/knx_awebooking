<?php
/**
 * Icomoon Icon Parser Provider.
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_Icomoon' ) ) :

	/**
	 * The AC_Icon_Parser_Icomoon Class.
	 */
	class AC_Icon_Parser_Icomoon extends AC_Icon_Parser_Abstract {
		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'selection.json';

		/**
		 * List of files, folders match folder structure.
		 *
		 * @var array
		 */
		protected static $directory_structure = array( 'demo-files/', 'fonts/', 'selection.json', 'style.css', 'demo.html' );

		/**
		 * Parse font icon name.
		 */
		protected function parse_icon_name() {
			$json = $this->get_parse_content();

			if ( isset( $json['metadata']['name'] ) && $json['metadata']['name'] ) {
				return sanitize_key( $json['metadata']['name'] );
			}

			if ( isset( $json['preferences']['fontPref']['metadata']['fontFamily'] ) && $json['preferences']['fontPref']['metadata']['fontFamily'] ) {
				return sanitize_key( $json['preferences']['fontPref']['metadata']['fontFamily'] );
			}
		}

		/**
		 * Parse icons.
		 */
		protected function parse_icons() {
			$json = $this->get_parse_content();

			// Return false if empty icons given.
			if ( empty( $json['icons'] ) || ( isset( $json['icons'] ) && ! is_array( $json['icons'] ) ) ) {
				return;
			}

			if ( empty( $json['preferences']['fontPref'] ) ) {
				return;
			}

			$fontconfig = $json['preferences']['fontPref'];

			foreach ( $json['icons'] as $raw_icon ) {
				if ( ! isset( $raw_icon['properties']['name'] ) ) {
					continue;
				}

				$postfix = isset( $fontconfig['postfix'] ) ? $fontconfig['postfix'] : '';
				$prefix = $fontconfig['prefix'];

				if ( $this->icon_name && 0 === strpos( $prefix, 'icon' ) ) {
					$prefix = $this->icon_name . '-';
				}

				$icon_name = $raw_icon['properties']['name'];
				$icon_class = $prefix . $icon_name . $postfix;

				if ( isset( $fontconfig['selector'] ) && 'class' === $fontconfig['selector'] && $fontconfig['classSelector'] ) {
					$selector = str_replace( '.', '', $fontconfig['classSelector'] );

					if ( $this->icon_name && 0 === strpos( $selector, 'icon' ) ) {
						$selector = $this->icon_name;
					}

					$icon_class = $selector . ' ' . $icon_class;
				}

				$this->add_icon( $icon_name, $icon_class );
			}
		}
	}
endif;
