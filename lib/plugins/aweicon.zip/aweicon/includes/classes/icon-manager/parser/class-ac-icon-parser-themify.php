<?php
/**
 * Themify Icon Parser Provider.
 *
 * @link https://themify.me/themify-icons
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_Themify' ) ) :

	/**
	 * The AC_Icon_Parser_Themify Class.
	 */
	class AC_Icon_Parser_Themify extends AC_Icon_Parser_Abstract {
		/**
		 * Where is provider is "LOCK" status
		 *
		 * We will tell with everybody is no parse CSS, no rename, etc...
		 *
		 * @var string
		 */
		public $lock = true;

		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'themify-icons.css';

		/**
		 * The style file name.
		 *
		 * @var string
		 */
		protected $style_name = 'themify-icons.css';

		/**
		 * List of files, folders match folder structure.
		 *
		 * @var array
		 */
		protected static $directory_structure = array( 'SVG/', 'demo-files/', 'index.html', 'themify-icons.css' );

		/**
		 * Parse font icon name.
		 */
		protected function parse_icon_name() {
			return 'themify-icons';
		}

		/**
		 * Parse icons.
		 */
		protected function parse_icons() {
			$handle = @fopen( $this->parse_path, 'r' );

			while ( ! feof( $handle ) ) {
				$line = trim( fgets( $handle, 4096 ) );

				if ( preg_match( '/^\.ti-([a-z0-9-]+):before/', $line, $matches ) ) {
					$this->add_icon( $matches[1], 'ti-' . $matches[1] );
				}
			}
		}
	}
endif;
