<?php
/**
 * Fontello Icon Parser Provider.
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_Fontello' ) ) :

	/**
	 * The AC_Icon_Parser_Fontello Class.
	 */
	class AC_Icon_Parser_Fontello extends AC_Icon_Parser_Abstract {
		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'config.json';

		/**
		 * The style file name.
		 *
		 * @var string
		 */
		protected $style_name = 'fontello.css';

		/**
		 * List of files, folders match folder structure.
		 *
		 * @var array
		 */
		protected static $directory_structure = array( 'css/', 'font/', 'config.json', 'demo.html' );

		/**
		 * Doing parser directory.
		 *
		 * Fallback finding style_path when style name is unstable.
		 */
		protected function do_parse_directory() {
			if ( ! $this->parse_path ) {
				return;
			}

			// We need icon_name first.
			$this->icon_name = $this->parse_icon_name();
			$styled_path = $this->directory . 'css/' . $this->icon_name . '.css';

			if ( file_exists( $styled_path ) ) {
				$this->style_path = $styled_path;
				$this->style_name = 'css/' . $this->icon_name . '.css';
			}
		}

		/**
		 * Parse font icon name.
		 */
		protected function parse_icon_name() {
			if ( $this->icon_name ) {
				return $this->icon_name;
			}

			// Parser JSON file content.
			$json = $this->get_parse_content();

			if ( isset( $json['name'] ) && $json['name'] ) {
				return sanitize_key( $json['name'] );
			}
		}

		/**
		 * Parse icons.
		 */
		protected function parse_icons() {
			$json = $this->get_parse_content();

			// Return false if empty icons given.
			if ( empty( $json['glyphs'] ) || ( isset( $json['glyphs'] ) && ! is_array( $json['glyphs'] ) ) ) {
				return;
			}

			if ( empty( $json['css_prefix_text'] ) ) {
				return;
			}

			foreach ( $json['glyphs'] as $raw_icon ) {
				if ( ! isset( $raw_icon['css'] ) ) {
					continue;
				}

				if ( isset( $json['css_use_suffix'] ) && true == $json['css_use_suffix'] ) {
					$icon_class = $raw_icon['css'] . $json['css_prefix_text'];
				} else {
					$icon_class = $json['css_prefix_text'] . $raw_icon['css'];
				}

				$this->add_icon( $raw_icon['css'], $icon_class );
			}
		}
	}
endif;
