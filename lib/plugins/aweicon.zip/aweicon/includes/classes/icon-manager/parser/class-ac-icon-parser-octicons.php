<?php
/**
 * Octicons Icon Parser Provider.
 *
 * @link https://octicons.github.com/
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_Octicons' ) ) :

	/**
	 * The AC_Icon_Parser_Octicons Class.
	 */
	class AC_Icon_Parser_Octicons extends AC_Icon_Parser_Abstract {
		/**
		 * Where is provider is "LOCK" status
		 *
		 * We will tell with everybody is no parse CSS, no rename, etc...
		 *
		 * @var string
		 */
		public $lock = true;

		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'lib/font/codepoints.json';

		/**
		 * The style file name.
		 *
		 * @var string
		 */
		protected $style_name = 'octicons.min.css';

		/**
		 * List of files, folders match folder structure.
		 *
		 * @var array
		 */
		protected static $directory_structure = array( 'build/font/', 'lib/font/codepoints.json' );

		/**
		 * Parse font icon name.
		 */
		protected function parse_icon_name() {
			return 'octicons';
		}

		/**
		 * Parse icons.
		 */
		protected function parse_icons() {
			$json = $this->get_parse_content();

			foreach ( $json as $name => $code ) {
				if ( ! is_string( $name ) ) {
					continue;
				}

				$this->add_icon( $name, 'octicon octicon-' . $name );
			}
		}
	}
endif;
