<?php
/**
 * PaymentFont Icon Parser Provider.
 *
 * @link http://paymentfont.io/
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_PaymentFont' ) ) :

	/**
	 * The AC_Icon_Parser_PaymentFont Class.
	 */
	class AC_Icon_Parser_PaymentFont extends AC_Icon_Parser_Abstract {
		/**
		 * Where is provider is "LOCK" status
		 *
		 * We will tell with everybody is no parse CSS, no rename, etc...
		 *
		 * @var string
		 */
		public $lock = true;

		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'css/paymentfont.css';

		/**
		 * The style file name.
		 *
		 * @var string
		 */
		protected $style_name = 'css/paymentfont.min.css';

		/**
		 * List of files, folders match folder structure.
		 *
		 * @var array
		 */
		protected static $directory_structure = array( 'css/', 'fonts/', 'css/paymentfont.css' );

		/**
		 * Parse font icon name.
		 */
		protected function parse_icon_name() {
			return 'paymentfont';
		}

		/**
		 * Parse icons.
		 */
		protected function parse_icons() {
			$handle = @fopen( $this->parse_path, 'r' );

			while ( ! feof( $handle ) ) {
				$line = trim( fgets( $handle, 4096 ) );

				if ( preg_match( '/^\.pf-([a-z0-9-]+):before\s{$/', $line, $matches ) ) {
					$this->add_icon( $matches[1], 'pf pf-' . $matches[1] );
				}
			}
		}
	}
endif;
