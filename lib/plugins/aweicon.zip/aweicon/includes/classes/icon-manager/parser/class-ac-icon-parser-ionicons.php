<?php
/**
 * Ionicons Icon Parser Provider.
 *
 * @link http://ionicons.com/
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AC_Icon_Parser_Ionicons' ) ) :

	/**
	 * The AC_Icon_Parser_Ionicons Class.
	 */
	class AC_Icon_Parser_Ionicons extends AC_Icon_Parser_Abstract {
		/**
		 * Where is provider is "LOCK" status
		 *
		 * We will tell with everybody is no parse CSS, no rename, etc...
		 *
		 * @var string
		 */
		public $lock = true;

		/**
		 * The parse file name.
		 *
		 * @var string
		 */
		protected $parse_name = 'manifest.json';

		/**
		 * The style file name.
		 *
		 * @var string
		 */
		protected $style_name = 'ionicons.min.css';

		/**
		 * List of files, folders match folder structure.
		 *
		 * @var array
		 */
		protected static $directory_structure = array( 'fonts/', 'css/ionicons.css', 'builder/manifest.json', 'cheatsheet.html' );

		/**
		 * Parse font icon name.
		 */
		protected function parse_icon_name() {
			return 'ionicons';
		}

		/**
		 * Parse icons.
		 */
		protected function parse_icons() {
			$json = $this->get_parse_content();

			// Return false if empty icons given.
			if ( empty( $json['icons'] ) ) {
				return;
			}

			foreach ( (array) $json['icons'] as $raw_icon ) {
				if ( ! isset( $raw_icon['name'] ) ) {
					continue;
				}

				$icon_class = 'ion-' . $raw_icon['name'];
				$this->add_icon( $raw_icon['name'], $icon_class );
			}
		}
	}
endif;
