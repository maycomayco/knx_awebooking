<?php
/**
 * Setup menus in WP admin.
 *
 * @author  Awethemes
 * @package Awecontent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once AWE_ICON_PLUGIN_DIR . '/includes/classes/icon-manager/class-ac-icon-manager-ui.php';

if ( ! class_exists( 'AIAdminMenus' ) ) :

	/**
	 * The AC_Admin_Menus Class.
	 */
	class AIAdminMenus {

		/**
		 * Main page slug.
		 *
		 * @var string
		 */
		protected $page_slug = 'ac-icon-manager';

		/**
		 * Hook in tabs.
		 */
		public function __construct() {
			add_action( 'admin_menu', array( $this, 'icon_manager_menu' ), 20 );
		}

		/**
		 * Add icon manager menu.
		 */
		public function icon_manager_menu() {
			
			$page_name = add_submenu_page( 'tools.php', esc_html__( 'Icon Manager', 'awecontent' ),  esc_html__( 'Icon Manager', 'awecontent' ) , 'manage_options', 'ac-icon-manager', array( $this, 'icon_manager_page' ) );
			add_action( 'load-' . $page_name, array( $this, '_page_no_header' ) );

		}

		/**
		 * Init the settings page.
		 */
		public function icon_manager_page() {
			$GLOBALS['AweIconManager_UI']->output();
		}


		/**
		 * Page no header.
		 */
		public function _page_no_header() {
			$_GET['noheader'] = true;
		}
	}
endif;

new AIAdminMenus;
