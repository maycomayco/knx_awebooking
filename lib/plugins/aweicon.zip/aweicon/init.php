<?php
/*
Plugin Name: Aweicon
Plugin URI: http://awethemes.com
Description: AWE Icon Manage
Author: AweTeam
Version: 1.0
Author URI: http://awethemes.com
Text Domain: aweicon
Domain Path: /languages/
*/
if ( ! defined( 'ABSPATH' ) ) { die( '<h3>Direct access to this file do not allow!</h3>' );
}

define( 'AWE_ICON_FILE', __FILE__ );
define( 'AWE_ICON_FILENAME', basename( __FILE__ ) );
define( 'AWE_ICON_PLUGIN_NAME', plugin_basename( dirname( __FILE__ ) ) );
define( 'AWE_ICON_PLUGIN_DIR', untrailingslashit( plugin_dir_path( AWE_ICON_FILE ) ) );
define( 'AWE_ICON_BASE_URL_PLUGIN', untrailingslashit( plugins_url( '', AWE_ICON_FILE ) ) );
define( 'AWE_ICON_VERSION','1.0' );

if ( ! function_exists( 'wp_get_current_user' ) ) {
	include( ABSPATH . 'wp-includes/pluggable.php' );
}

if ( ! class_exists( 'AweIcon' ) ) {
	require_once AWE_ICON_PLUGIN_DIR . '/includes/aweicon.php';
}

