(function($) {
  'use strict';

  /**
   * IconPackManager
   */
  var IconPackManager = function () {
    var self = this;

    if (window.acIcons.length === 0) {

      $('.no-icons').show();
      $('.search-icons').hide();

    } else {

      this.handlerDelete();

      // Build list icons each icon pack.
      _.each(window.acIcons, function (icons, name) {
        self._iconsBuilder('ac-icon-' + name, icons);
      });

      // Build main list icons pack.
      this.iconsPackList = new List('icon-manager-wrap', {
        page: 6,
        plugins: [ ListPagination() ],
        valueNames: ['icon_pack_name', 'icon_pack_id'],
      });

      var onUpdateEvent = _.debounce(function () {
        self.onUpdateDataList(self.iconsPackList);
      }, 150);

      this.onUpdateDataList(this.iconsPackList);
      this.iconsPackList.on('updated', onUpdateEvent);
      $(document).on('icons-pack-change', onUpdateEvent);
    }
  };

  _.extend(IconPackManager.prototype, {

    /**
     * Add error message.
     *
     * @param {string} message Message text.
     */
    addError: function (message) {
      this.addMessage(message, 'error');
    },

    /**
     * Add a message.
     *
     * @param {string} message Message text.
     * @param {string} type    Message type.
     */
    addMessage: function (message, type) {
      type = type || 'success';
      var _template = '<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>';

      $('.wrap > .notice').remove();
      $('.wrap > .wp-filter').before(_template);

      // Make is-dismissible is working again.
      $(document).trigger('wp-updates-notice-added');
    },

    /**
     * Handler update template.
     */
    onUpdateDataList: function (list) {
      $('.filter-count > .count').html(list.matchingItems.length);

      if (list.matchingItems.length === 0) {
        $('.no-icons').show();
      } else {
        $('.no-icons').hide();
      }

      if ($(document).find('.ac-pagination > li').length <= 1) {
        $(document).find('.ac-pagination').hide();
      } else {
        $(document).find('.ac-pagination').show();
      }
    },

    /**
     * Handler AJAX delete a icon pack.
     */
    handlerDelete: function () {
      var self = this;

      // Delete a icon pack.
      $(document).on('click', '.delete-button', function(e) {
        e.preventDefault();
        self._makeAjaxDelete($(this));
      });
    },

    /**
     * Make a AJAX delete icon request.
     */
    _makeAjaxDelete: function ($el, data) {
      var self = this;
      var $mainbox = $el.closest('.ac-icon-manager__box');

      $mainbox.addClass('loading');

      var ajax = $.ajax({
        url: ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: {
          action: 'ac_delete_icon',
          icon_slug: $el.data('icon'),
          _ajax_nonce: $el.data('nonce'),
        }
      })
      .done(function(response) {
        if (! response.data) {
          return;
        }

        switch (response.success) {
          case true:
            self.iconsPackList.remove('icon_pack_id', $el.data('icon'));
            self.addMessage(response.data.message);
            break;

          case false:
            self.addError(response.data.message);
            break;
        }
      })
      .fail(function(response) {
        alert(':(');
      })
      .always(function(response) {
        $mainbox.removeClass('loading');
      });

      return ajax;
    },

    /**
     * Icons Builder
     *
     * @param  {string} id    Main icon-box ID.
     * @param  {object} icons Icons list.
     * @return {List|null}
     */
    _iconsBuilder: function (id, icons) {
      var sId = '#' + id;
      $(sId).find('.spinner').hide();

      if (_.isEmpty(icons)) {
        return;
      }

      var markup = '<li><i class="<%= classes %>" aria-hidden="true"></i> <div class="zoom-icon"><i class="<%= classes %>" aria-hidden="true"></i><span class="icon-label name"><%= name %></span> <span class="screen-reader-text classes"><%= classes %></span></div></li>';
      var iconsHtml = '';

      _.each(icons, function(icon) {
        var compiled = _.template(markup);
        iconsHtml += compiled(icon);
      });

      $(sId).find('ul.list').html(iconsHtml);

      new List(id, {
        page: 2500,
        plugins: [ ListFuzzySearch() ],
        valueNames: ['name', 'classes'],
      });
    },

  });

  /**
   * Document ready!!!
   */
  $(function () {
    // Handler toggle form upload icon.
    var $uploadContainer = $('.welcome-panel');
    $uploadContainer.hide();

    $(document).on('click', '.add-new-h2, .welcome-panel-close', function(e) {
      e.preventDefault();
      $uploadContainer.toggle();
    });

    // Fire IconPackManager
    window.IconPackManager = new IconPackManager;
  });

})(jQuery);
